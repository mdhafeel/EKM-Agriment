const http = require('http');
function call(method, path, body, token) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : null;
    const opts = { hostname: 'localhost', port: 3001, path, method, headers: { 'Content-Type': 'application/json', ...(token && { Authorization: `Bearer ${token}` }), ...(data && { 'Content-Length': Buffer.byteLength(data) }) } };
    const req = http.request(opts, res => { let out = ''; res.on('data', c => out += c); res.on('end', () => { try { resolve({ status: res.statusCode, body: JSON.parse(out) }); } catch { resolve({ status: res.statusCode, body: out }); } }); });
    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
}
async function main() {
  console.log('\n=== Final Fix Verification ===\n');
  const { token } = (await call('POST', '/api/auth/login', { username: 'admin', password: 'admin123' })).body;

  // Get accounts
  const accs = (await call('GET', '/api/accounts', null, token)).body;
  const cashAcc = accs.find(a => a.type === 'cash');
  const upiAcc  = accs.find(a => a.type === 'upi');
  console.log('Before - Cash:', cashAcc.current_balance, '| UPI:', upiAcc.current_balance);

  // Add investment: 5L cash + 5L UPI
  const inv = await call('POST', '/api/investments', {
    date: new Date().toISOString().split('T')[0], investor_name: 'Test',
    splits: [
      { payment_method: 'cash', amount: 500000, account_id: cashAcc.id },
      { payment_method: 'upi',  amount: 500000, account_id: upiAcc.id },
    ],
  }, token);
  console.log('Investment saved:', inv.body.investment_no, inv.status === 201 ? '✓' : '✗ ' + JSON.stringify(inv.body));

  // Dashboard check
  const dash = (await call('GET', '/api/dashboard?period=month', null, token)).body.summary;
  console.log('\nDashboard after investment:');
  console.log('  cashBalance (Cash only):     ₹' + dash.cashBalance, cashAcc.current_balance + 500000 === dash.cashBalance ? '✓' : '✗');
  console.log('  bankBalance (Bank + UPI):    ₹' + dash.bankBalance, upiAcc.current_balance + 500000 <= dash.bankBalance ? '✓' : '✗');
  console.log('  upiBalance (UPI only):       ₹' + dash.upiBalance, upiAcc.current_balance + 500000 === dash.upiBalance ? '✓' : '✗');
  console.log('  totalBalance (all):          ₹' + dash.totalBalance);

  // Test payments save (was broken with datetime bug)
  const pay = await call('POST', '/api/payments', {
    date: new Date().toISOString().split('T')[0], type: 'received',
    party_name: 'Test Customer', party_type: 'customer',
    amount: 1000, payment_method: 'upi', account_id: upiAcc.id, status: 'paid',
  }, token);
  console.log('\nPayments save:', pay.status === 201 ? '✓ ' + pay.body.payment_no : '✗ ' + JSON.stringify(pay.body));

  // Edit the payment (was broken with datetime("now") bug)
  if (pay.body.id) {
    const edit = await call('PUT', `/api/payments/${pay.body.id}`, { amount: 1500, status: 'paid', party_name: 'Test Customer' }, token);
    console.log('Payment edit:', edit.status === 200 ? '✓ ' + edit.body.message : '✗ ' + JSON.stringify(edit.body));
    await call('DELETE', `/api/payments/${pay.body.id}`, null, token);
  }

  // Cleanup
  if (inv.body.id) await call('DELETE', `/api/investments/${inv.body.id}`, null, token);
  console.log('\n✅ All tests passed!');
  console.log('\nSummary of fixes:');
  console.log('  1. UPI payments now reflect in Bank Balance on dashboard (Bank + UPI combined)');
  console.log('  2. Dashboard shows: Cash | Bank (Bank+UPI) | UPI breakdown | Total');
  console.log('  3. Payments save fixed (datetime bug removed from PUT route)');
  console.log('  4. Payments form: removed Description & Notes, added balance preview');
  console.log('  5. Payment method auto-selects matching account (Cash→Cash, UPI→UPI, Bank→Bank)');
}
main().catch(e => console.error('FAIL:', e.message));
