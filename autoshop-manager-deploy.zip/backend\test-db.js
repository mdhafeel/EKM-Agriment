try {
  const Database = require('better-sqlite3');
  const db = new Database(':memory:');
  db.exec('CREATE TABLE test (id INTEGER PRIMARY KEY, val TEXT)');
  db.prepare('INSERT INTO test (val) VALUES (?)').run('hello');
  const row = db.prepare('SELECT * FROM test').get();
  console.log('better-sqlite3 OK:', row);
  db.close();
} catch (e) {
  console.error('better-sqlite3 FAILED:', e.message);
  process.exit(1);
}
