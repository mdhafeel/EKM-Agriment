const http = require('http');

function call(method, path, body, token) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : null;
    const opts = {
      hostname: 'localhost', port: 3001, path, method,
      headers: {
        'Content-Type': 'application/json',
        ...(token && { Authorization: `Bearer ${token}` }),
        ...(data && { 'Content-Length': Buffer.byteLength(data) }),
      },
    };
    const req = http.request(opts, res => {
      let out = '';
      res.on('data', c => out += c);
      res.on('end', () => {
        try { resolve({ status: res.statusCode, body: JSON.parse(out) }); }
        catch { resolve({ status: res.statusCode, body: out }); }
      });
    });
    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
}

async function main() {
  console.log('\n=== Delete Operations Test ===\n');

  const login = await call('POST', '/api/auth/login', { username: 'admin', password: 'admin123' });
  const token = login.body.token;
  console.log('[1] Login:', login.status === 200 ? '✓' : '✗');

  const today = new Date().toISOString().split('T')[0];
  const accs  = (await call('GET', '/api/accounts', null, token)).body;
  const cashId = accs.find(a => a.type === 'cash')?.id;
  const upiId  = accs.find(a => a.type === 'upi')?.id;

  // ── Test Investment delete ──────────────────────────────
  console.log('\n--- Investment ---');
  const inv = await call('POST', '/api/investments', {
    date: today, investor_name: 'Test Investor',
    splits: [
      { payment_method: 'cash', amount: 100000, account_id: cashId },
      { payment_method: 'upi',  amount: 50000,  account_id: upiId  },
    ],
  }, token);
  console.log('  Create:', inv.status === 201 ? `✓ ${inv.body.investment_no}` : `✗ ${JSON.stringify(inv.body)}`);

  const accs2 = (await call('GET', '/api/accounts', null, token)).body;
  console.log('  Cash after add: ₹' + accs2.find(a => a.type === 'cash')?.current_balance);
  console.log('  UPI  after add: ₹' + accs2.find(a => a.type === 'upi')?.current_balance);

  if (inv.body.id) {
    const del = await call('DELETE', `/api/investments/${inv.body.id}`, null, token);
    console.log('  Delete:', del.status === 200 ? `✓ ${del.body.message}` : `✗ ${JSON.stringify(del.body)}`);
    const accs3 = (await call('GET', '/api/accounts', null, token)).body;
    console.log('  Cash after delete: ₹' + accs3.find(a => a.type === 'cash')?.current_balance, '(should restore to 0)');
    console.log('  UPI  after delete: ₹' + accs3.find(a => a.type === 'upi')?.current_balance, '(should restore to 0)');
  }

  // ── Test Expense delete ─────────────────────────────────
  console.log('\n--- Expense ---');
  const exp = await call('POST', '/api/expenses', {
    date: today, paid_to: 'Test Vendor',
    splits: [
      { payment_method: 'cash', amount: 5000, account_id: cashId },
      { payment_method: 'upi',  amount: 3000, account_id: upiId  },
    ],
  }, token);
  console.log('  Create:', exp.status === 201 ? `✓ ${exp.body.expense_no}` : `✗ ${JSON.stringify(exp.body)}`);

  const accs4 = (await call('GET', '/api/accounts', null, token)).body;
  console.log('  Cash after expense: ₹' + accs4.find(a => a.type === 'cash')?.current_balance);

  if (exp.body.id) {
    const del2 = await call('DELETE', `/api/expenses/${exp.body.id}`, null, token);
    console.log('  Delete:', del2.status === 200 ? `✓ ${del2.body.message}` : `✗ ${JSON.stringify(del2.body)}`);
    const accs5 = (await call('GET', '/api/accounts', null, token)).body;
    console.log('  Cash after delete: ₹' + accs5.find(a => a.type === 'cash')?.current_balance, '(should restore)');
  }

  // ── Test Spare Parts delete ─────────────────────────────
  console.log('\n--- Spare Parts ---');
  const part = await call('POST', '/api/spare-parts', {
    part_name: 'Test Part', purchase_price: 100, selling_price: 150, opening_stock: 10,
  }, token);
  console.log('  Create:', part.status === 201 ? `✓ ${part.body.part_code}` : `✗ ${JSON.stringify(part.body)}`);

  if (part.body.id) {
    const del3 = await call('DELETE', `/api/spare-parts/${part.body.id}`, null, token);
    console.log('  Delete:', del3.status === 200 ? `✓ ${del3.body.message}` : `✗ ${JSON.stringify(del3.body)}`);

    // Verify part is gone from stock list
    const stockCheck = await call('GET', `/api/spare-parts?search=Test Part`, null, token);
    const stillThere = stockCheck.body.parts?.find(p => p.id === part.body.id);
    console.log('  Removed from list:', !stillThere ? '✓' : '✗ still visible');
  }

  console.log('\n=== Done ===\n');
}

main().catch(e => console.error('Test error:', e.message));
