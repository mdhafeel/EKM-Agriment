const http = require('http');

function call(method, path, body, token) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : null;
    const opts = {
      hostname: 'localhost', port: 3001, path, method,
      headers: {
        'Content-Type': 'application/json',
        ...(token && { Authorization: `Bearer ${token}` }),
        ...(data && { 'Content-Length': Buffer.byteLength(data) }),
      },
    };
    const req = http.request(opts, res => {
      let out = '';
      res.on('data', c => out += c);
      res.on('end', () => {
        try { resolve({ status: res.statusCode, body: JSON.parse(out) }); }
        catch { resolve({ status: res.statusCode, body: out }); }
      });
    });
    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
}

async function main() {
  console.log('\n=== Expense Balance Fix Test ===\n');

  // Login
  const login = await call('POST', '/api/auth/login', { username: 'admin', password: 'admin123' });
  const token = login.body.token;
  console.log('[1] Login:', login.status === 200 ? '✓' : '✗');

  // Get accounts
  const accounts = await call('GET', '/api/accounts', null, token);
  console.log('[2] Accounts:', accounts.status === 200 ? '✓' : '✗', `(${accounts.body.length} accounts)`);
  const cashAcc = accounts.body.find(a => a.type === 'cash');
  console.log(`    Cash account: "${cashAcc?.name}" — balance: ₹${cashAcc?.current_balance}`);

  // Test new balance endpoint
  if (cashAcc) {
    const bal = await call('GET', `/api/expenses/account-balance/${cashAcc.id}`, null, token);
    console.log('[3] Balance endpoint:', bal.status === 200 ? '✓' : '✗',
      `— current_balance: ₹${bal.body.current_balance}`);
  }

  // Add an expense (record ₹500 from cash)
  const today = new Date().toISOString().split('T')[0];
  const addExp = await call('POST', '/api/expenses', {
    date: today,
    category_id: null,
    category_name: 'Test',
    amount: 500,
    payment_method: 'cash',
    account_id: cashAcc?.id || null,
    paid_to: 'Test Vendor',
    description: 'Test expense for balance check',
  }, token);
  console.log('[4] Add expense ₹500:', addExp.status === 201 ? '✓' : '✗',
    addExp.body.expense_no || addExp.body.error);

  // Check balance changed
  if (cashAcc) {
    const bal2 = await call('GET', `/api/expenses/account-balance/${cashAcc.id}`, null, token);
    const expectedBalance = (cashAcc.current_balance || 0) - 500;
    const actualBalance   = bal2.body.current_balance;
    console.log('[5] Balance after ₹500 expense:',
      `expected ₹${expectedBalance}, got ₹${actualBalance}`,
      actualBalance === expectedBalance ? '✓' : '✗');
  }

  // Edit the expense (change amount to ₹800 — diff of ₹300 more)
  if (addExp.status === 201) {
    const editExp = await call('PUT', `/api/expenses/${addExp.body.id}`, {
      date: today,
      amount: 800,
      payment_method: 'cash',
      account_id: cashAcc?.id || null,
      description: 'Updated expense',
    }, token);
    console.log('[6] Edit expense to ₹800:', editExp.status === 200 ? '✓' : '✗', editExp.body.message || editExp.body.error);

    if (cashAcc) {
      const bal3 = await call('GET', `/api/expenses/account-balance/${cashAcc.id}`, null, token);
      const expectedBalance2 = (cashAcc.current_balance || 0) - 800;
      console.log('[7] Balance after edit to ₹800:',
        `expected ₹${expectedBalance2}, got ₹${bal3.body.current_balance}`,
        bal3.body.current_balance === expectedBalance2 ? '✓' : '✗');
    }

    // Delete expense (balance should restore)
    const delExp = await call('DELETE', `/api/expenses/${addExp.body.id}`, null, token);
    console.log('[8] Delete expense:', delExp.status === 200 ? '✓' : '✗');

    if (cashAcc) {
      const bal4 = await call('GET', `/api/expenses/account-balance/${cashAcc.id}`, null, token);
      console.log('[9] Balance after delete (should restore):',
        `expected ₹${cashAcc.current_balance}, got ₹${bal4.body.current_balance}`,
        bal4.body.current_balance === cashAcc.current_balance ? '✓' : '✗');
    }
  }

  console.log('\n✅ All expense balance checks complete!\n');
  console.log('The Expenses page now shows:');
  console.log('  • Current account balance next to account dropdown');
  console.log('  • Live remaining balance as you type the amount');
  console.log('  • Red warning if balance would go negative');
  console.log('  • Account balances strip on the main page\n');
}

main().catch(e => console.error('Test failed:', e.message));
