const http = require('http');
function call(method, path, body, token) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : null;
    const opts = { hostname:'localhost', port:3001, path, method, headers:{'Content-Type':'application/json',...(token&&{Authorization:`Bearer ${token}`}),...(data&&{'Content-Length':Buffer.byteLength(data)})} };
    const req = http.request(opts, res=>{let out='';res.on('data',c=>out+=c);res.on('end',()=>{try{resolve({status:res.statusCode,body:JSON.parse(out)})}catch{resolve({status:res.statusCode,body:out})}})});
    req.on('error',reject); if(data) req.write(data); req.end();
  });
}
async function main() {
  const {token} = (await call('POST','/api/auth/login',{username:'admin',password:'admin123'})).body;
  const res = await call('GET','/api/settings/export-excel-data',null,token);
  if (res.status === 200) {
    const d = res.body;
    console.log('✓ Export endpoint works!');
    console.log('  Summary keys:', Object.keys(d.summary).join(', '));
    console.log('  Sales rows:', d.sales.length);
    console.log('  Purchases rows:', d.purchases.length);
    console.log('  Expenses rows:', d.expenses.length);
    console.log('  Investments rows:', d.investments.length);
    console.log('  Payments rows:', d.payments.length);
    console.log('  Customers rows:', d.customers.length);
    console.log('  Stock rows:', d.stock.length);
    console.log('  Monthly P&L rows:', d.monthlyPL.length);
  } else {
    console.log('✗ Failed:', res.status, res.body);
  }
}
main().catch(console.error);
