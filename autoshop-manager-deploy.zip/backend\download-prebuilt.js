const { execSync } = require('child_process');
const path = require('path');
const fs = require('fs');

const bsqliteDir = path.join(__dirname, 'node_modules', 'better-sqlite3');
const pkg = JSON.parse(fs.readFileSync(path.join(bsqliteDir, 'package.json'), 'utf8'));
console.log('better-sqlite3 version:', pkg.version);

// Find prebuild-install cmd shim
const candidates = [
  path.join(__dirname, 'node_modules', '.bin', 'prebuild-install.cmd'),
  path.join(bsqliteDir, 'node_modules', '.bin', 'prebuild-install.cmd'),
  path.join(__dirname, 'node_modules', 'prebuild-install', 'bin.js'),
  path.join(bsqliteDir, 'node_modules', 'prebuild-install', 'bin.js'),
];

let prebuildBin = null;
for (const c of candidates) {
  if (fs.existsSync(c)) { prebuildBin = c; break; }
}

if (!prebuildBin) {
  console.log('prebuild-install not found in candidates, trying npx...');
  try {
    const out = execSync('npx prebuild-install --runtime napi --tag-prefix v', {
      cwd: bsqliteDir, timeout: 120000, encoding: 'utf8'
    });
    console.log('npx prebuild-install succeeded:', out);
  } catch (e) {
    console.error('npx failed:', e.stdout, e.stderr);
  }
} else {
  console.log('Using:', prebuildBin);
  const isJs = prebuildBin.endsWith('.js');
  const cmd = isJs
    ? `node "${prebuildBin}" --runtime napi --tag-prefix v`
    : `"${prebuildBin}" --runtime napi --tag-prefix v`;
  console.log('Running:', cmd);
  try {
    const out = execSync(cmd, { cwd: bsqliteDir, timeout: 120000, encoding: 'utf8' });
    console.log('Success:', out);
  } catch (e) {
    console.error('Failed:', e.message);
    console.log('stdout:', e.stdout);
    console.log('stderr:', e.stderr);
  }
}

// Test if it works now
try {
  const Database = require('better-sqlite3');
  const db = new Database(':memory:');
  db.exec('CREATE TABLE t (id INTEGER PRIMARY KEY, v TEXT)');
  db.prepare('INSERT INTO t (v) VALUES (?)').run('ok');
  const row = db.prepare('SELECT * FROM t').get();
  console.log('better-sqlite3 WORKS:', row);
  db.close();
} catch (e) {
  console.error('better-sqlite3 still FAILED:', e.message);
}
