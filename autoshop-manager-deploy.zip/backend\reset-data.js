/**
 * reset-data.js
 * Clears ALL business transactions but keeps:
 *   - Admin user and staff users
 *   - Account definitions (Cash, Bank, UPI) — balances reset to 0
 *   - Settings (business name, etc.)
 *   - Expense categories
 *   - Parts categories & subcategories
 */

const { initializeDatabase, getDb } = require('./src/db/schema');

initializeDatabase();
const db = getDb();

const reset = db.transaction(() => {
  // Transaction data
  db.exec('DELETE FROM investment_splits');
  db.exec('DELETE FROM investments');
  db.exec('DELETE FROM sale_items');
  db.exec('DELETE FROM sales');
  db.exec('DELETE FROM purchase_items');
  db.exec('DELETE FROM purchases');
  db.exec('DELETE FROM expenses');
  db.exec('DELETE FROM payments');
  db.exec('DELETE FROM ledger');
  db.exec('DELETE FROM account_transfers');
  db.exec('DELETE FROM stock_movements');
  db.exec('DELETE FROM invoices');
  db.exec('DELETE FROM notifications');
  db.exec('DELETE FROM daily_closing');
  db.exec('DELETE FROM audit_logs');

  // Spare parts (inventory items) — reset stock to 0
  db.exec('DELETE FROM spare_parts');

  // Customers & Suppliers
  db.exec('DELETE FROM customers');
  db.exec('DELETE FROM suppliers');

  // Reset all account balances to 0
  db.exec('UPDATE accounts SET current_balance = 0, updated_at = strftime(\'%Y-%m-%d %H:%M:%S\',\'now\')');

  // Reset SQLite auto-increment sequences for cleanliness
  db.exec(`DELETE FROM sqlite_sequence WHERE name IN (
    'investments','investment_splits','sales','sale_items',
    'purchases','purchase_items','expenses','payments',
    'ledger','account_transfers','stock_movements','invoices',
    'notifications','daily_closing','audit_logs',
    'spare_parts','customers','suppliers'
  )`);

  console.log('✅ All business data cleared.');
  console.log('   Kept: users, accounts (balances reset to ₹0), settings, categories.');
});

try {
  reset();

  // Verify
  const counts = {
    investments:  db.prepare('SELECT COUNT(*) as c FROM investments').get().c,
    sales:        db.prepare('SELECT COUNT(*) as c FROM sales').get().c,
    purchases:    db.prepare('SELECT COUNT(*) as c FROM purchases').get().c,
    expenses:     db.prepare('SELECT COUNT(*) as c FROM expenses').get().c,
    payments:     db.prepare('SELECT COUNT(*) as c FROM payments').get().c,
    customers:    db.prepare('SELECT COUNT(*) as c FROM customers').get().c,
    suppliers:    db.prepare('SELECT COUNT(*) as c FROM suppliers').get().c,
    spare_parts:  db.prepare('SELECT COUNT(*) as c FROM spare_parts').get().c,
    users:        db.prepare('SELECT COUNT(*) as c FROM users').get().c,
    accounts:     db.prepare('SELECT COUNT(*) as c FROM accounts').get().c,
    categories:   db.prepare('SELECT COUNT(*) as c FROM parts_categories').get().c,
    settings:     db.prepare('SELECT COUNT(*) as c FROM settings').get().c,
  };

  console.log('\nVerification — record counts after reset:');
  Object.entries(counts).forEach(([k, v]) => {
    const kept = ['users','accounts','categories','settings'].includes(k);
    console.log(`  ${kept ? '✓ kept' : '  zero'} ${k}: ${v}`);
  });

  const accounts = db.prepare('SELECT name, type, current_balance FROM accounts').all();
  console.log('\nAccount balances reset to:');
  accounts.forEach(a => console.log(`  ${a.name} (${a.type}): ₹${a.current_balance}`));

  console.log('\n🎉 Database reset complete. Ready for fresh use.');
} catch (e) {
  console.error('❌ Reset failed:', e.message);
  process.exit(1);
}
