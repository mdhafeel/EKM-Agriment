console.log('napi:', process.versions.napi);
console.log('node:', process.version);
console.log('platform:', process.platform, process.arch);
