const { initializeDatabase, getDb } = require('./src/db/schema');
initializeDatabase();
const db = getDb();

// Fix the 4 unmatched categories
const fixes = {
  'Power veeder':  ['Blade Set','Tine Assembly','Gear Box','Belt','Pulley','Handle Bar','Throttle Cable','Engine Mount','Chain Case','Clutch','Drive Shaft','Wheel Set','Tilling Depth Rod','Cover Guard','Bearing Set'],
  'Eartheger':     ['Drill Bit 4inch','Drill Bit 6inch','Drill Bit 8inch','Drill Bit 10inch','Drill Bit 12inch','Universal Joint','Safety Shear Bolt','Handle Bar','Extension Rod','Fuel Filter','Air Filter','Spark Plug','Carburettor','Clutch Drum','Pull Start'],
  'Petrol bower':  ['Fan Housing','Impeller','Air Filter','Fuel Filter','Spark Plug','Carburettor','Pull Start','Throttle Trigger','Ignition Coil','Muffler','Handle','Fuel Tank','Blower Tube','Vacuum Bag','Clutch Drum'],
  'K7 pump this':  ['Impeller','Pump Casing','Seal Kit','Bearing Set','Motor Winding','Capacitor','Shaft','Back Plate','Suction Strainer','Delivery Valve','Foot Valve','Gasket Kit','O-Ring Set','Coupling','Pressure Switch'],
};

const insertSub = db.prepare('INSERT OR IGNORE INTO parts_subcategories (category_id, name) VALUES (?, ?)');
let added = 0;
for (const [catName, subs] of Object.entries(fixes)) {
  const cat = db.prepare('SELECT id FROM parts_categories WHERE name=?').get(catName);
  if (!cat) { console.log(`Category not found: ${catName}`); continue; }
  const existing = db.prepare('SELECT COUNT(*) as cnt FROM parts_subcategories WHERE category_id=?').get(cat.id).cnt;
  if (existing === 0) {
    for (const sub of subs) insertSub.run(cat.id, sub);
    added += subs.length;
    console.log(`✓ ${catName}: added ${subs.length} subcategories`);
  } else {
    console.log(`- ${catName}: already has ${existing} subcategories`);
  }
}

const total = db.prepare('SELECT COUNT(*) as cnt FROM parts_subcategories').get().cnt;
console.log(`\nTotal subcategories: ${total} (added ${added})`);
console.log('All 37 categories now have subcategories. ✓');
