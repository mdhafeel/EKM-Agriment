const http = require('http');

function post(path, body) {
  return new Promise((resolve, reject) => {
    const data = JSON.stringify(body);
    const opts = {
      hostname: 'localhost', port: 3001, path,
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) }
    };
    const req = http.request(opts, res => {
      let out = '';
      res.on('data', c => out += c);
      res.on('end', () => resolve({ status: res.statusCode, body: JSON.parse(out) }));
    });
    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

function get(path) {
  return new Promise((resolve, reject) => {
    http.get(`http://localhost:3001${path}`, res => {
      let out = '';
      res.on('data', c => out += c);
      res.on('end', () => resolve({ status: res.statusCode, body: JSON.parse(out) }));
    }).on('error', reject);
  });
}

async function run() {
  console.log('\n=== AutoShop Manager Health Check ===\n');

  // Health
  const health = await get('/api/health');
  console.log('[1] Health:', health.status === 200 ? '✓ OK' : '✗ FAIL', health.body.timestamp);

  // Login
  const login = await post('/api/auth/login', { username: 'admin', password: 'admin123' });
  console.log('[2] Admin login:', login.status === 200 ? '✓ OK' : '✗ FAIL', login.status === 200 ? `(user: ${login.body.user.full_name})` : login.body.error);

  if (login.status !== 200) { console.log('\n✗ Login failed — stopping.'); return; }

  const token = login.body.token;
  const authHeader = `Bearer ${token}`;

  // Dashboard
  function authGet(path) {
    return new Promise((resolve, reject) => {
      const opts = { hostname: 'localhost', port: 3001, path, headers: { Authorization: authHeader } };
      http.get(opts, res => {
        let out = '';
        res.on('data', c => out += c);
        res.on('end', () => resolve({ status: res.statusCode, body: JSON.parse(out) }));
      }).on('error', reject);
    });
  }

  const dash = await authGet('/api/dashboard?period=month');
  console.log('[3] Dashboard:', dash.status === 200 ? '✓ OK' : '✗ FAIL', dash.status === 200 ? `(cash: ₹${dash.body.summary?.cashBalance ?? 0})` : dash.body.error);

  const accounts = await authGet('/api/accounts');
  console.log('[4] Accounts:', accounts.status === 200 ? '✓ OK' : '✗ FAIL', accounts.status === 200 ? `(${accounts.body.length} accounts seeded)` : accounts.body.error);

  const parts = await authGet('/api/spare-parts?limit=1');
  console.log('[5] Spare parts API:', parts.status === 200 ? '✓ OK' : '✗ FAIL');

  const customers = await authGet('/api/customers?limit=1');
  console.log('[6] Customers API:', customers.status === 200 ? '✓ OK' : '✗ FAIL');

  const notifs = await authGet('/api/notifications');
  console.log('[7] Notifications:', notifs.status === 200 ? '✓ OK' : '✗ FAIL');

  const settings = await authGet('/api/settings');
  console.log('[8] Settings:', settings.status === 200 ? '✓ OK' : '✗ FAIL', settings.status === 200 ? `(business: ${settings.body.business_name})` : '');

  console.log('\n=== All checks complete ===');
  console.log('\n🚀 Application is ready at: http://localhost:5173');
  console.log('   Login: admin / admin123\n');
}

run().catch(e => console.error('Check failed:', e.message));
